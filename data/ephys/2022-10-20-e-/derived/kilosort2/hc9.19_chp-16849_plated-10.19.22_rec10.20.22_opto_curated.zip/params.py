dat_path = 'recording.dat'
n_channels_dat = 983
dtype = 'int16'
offset = 0
sample_rate = 20000.
hp_filtered = False