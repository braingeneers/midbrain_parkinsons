#!/bin/bash
cd "/project/matlab/"
# matlab -nosplash -nodisplay -log -r kilosort2_master
./run_kilosort_compiled.sh /usr/local/MATLAB/MATLAB_Runtime/v97 /project/SpikeSorting/inter/sorted/kilosort2
                